var people = ["Mary", "Bobby", "Judy", "Eddie", "Herbie", "Paul", "Bobby"];
var otherPeople = ["Teddy", "Goergie", "Katty", "Jack"];

// people = people.concat(otherPeople);

// people = people.indexOf("Eddie");

// people = people.join(" # ");

// people = people.lastIndexOf("Bobby");

// people = people.pop();
// people.pop();

// people = people.push("Teddy");
// people.push("Teddy");

// people = people.reverse();
// people.shift();

// people.unshift("Teddy");

// people = people.slice(0,3);
// people = people.sort();

// people.splice(1,0,"Cathy");


// document.getElementById("peopleIKnow").innerHTML = people.toString();
document.getElementById("peopleIKnow").innerHTML = people.valueOf();



